/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { UserCheck, MapPin, RefreshCcw, Loader2, ThumbsUp, ClipboardList, AlertCircle } from "lucide-react";
import { Facility, FacilityType, Incident, Volunteer } from "./types";

interface VolunteerDashboardProps {
  facilities: Facility[];
  incidents: Incident[];
  volunteers: Volunteer[];
  onUpdateCrowd: (facilityId: string, crowdLevel: string, waitTime: number) => Promise<void>;
  onResolveIncident: (incidentId: string) => Promise<void>;
}

export default function VolunteerDashboard({
  facilities,
  incidents,
  volunteers,
  onUpdateCrowd,
  onResolveIncident
}: VolunteerDashboardProps) {
  // Hardcoded as Volunteer "Carlos Silva" for demonstration
  const volId = "vol-1";
  const myRoster = volunteers.find(v => v.id === volId) || volunteers[0];

  const [selectedFacilityId, setSelectedFacilityId] = useState("");
  const [crowdLevel, setCrowdLevel] = useState("Medium");
  const [waitTime, setWaitTime] = useState(10);
  const [isUpdating, setIsUpdating] = useState(false);

  // Active incident assigned to me
  const assignedIncidents = incidents.filter(i => i.assignedVolunteerId === volId && i.status !== "Resolved");

  const handleUpdateCrowd = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedFacilityId) return;

    setIsUpdating(true);
    try {
      await onUpdateCrowd(selectedFacilityId, crowdLevel, waitTime);
      setSelectedFacilityId("");
    } catch (e) {
      console.error(e);
    } finally {
      setIsUpdating(false);
    }
  };

  return (
    <div className="space-y-4">
      {/* Volunteer Passport */}
      <div className="bg-gradient-to-r from-indigo-950 to-slate-900 border border-indigo-900/50 p-4 rounded-2xl shadow-xl flex items-center justify-between">
        <div className="flex items-center gap-3">
          <img
            src={myRoster.avatarUrl || "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&h=100&fit=crop"}
            alt={myRoster.name}
            className="w-12 h-12 rounded-full border-2 border-indigo-500 object-cover"
          />
          <div>
            <span className="text-[10px] font-mono tracking-wider bg-indigo-500/10 text-indigo-400 border border-indigo-500/20 px-2 py-0.5 rounded uppercase">
              Rostered Volunteer Guide
            </span>
            <h3 className="font-display font-bold text-base text-slate-100 mt-1">
              {myRoster.name}
            </h3>
            <p className="text-xs text-slate-400">
              Roster: <strong className="text-slate-300">{myRoster.role}</strong> • Stationed: <strong>{myRoster.locationName}</strong>
            </p>
          </div>
        </div>

        <div className="text-right">
          <span className="text-[10px] font-mono text-slate-500 block uppercase">TASKS RESOLVED</span>
          <p className="text-xl font-bold text-indigo-400 font-display">
            {myRoster.tasksCompleted}
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* My Assignments list */}
        <div className="bg-slate-900/40 border border-slate-800 p-4 rounded-2xl shadow-xl flex flex-col justify-between">
          <div>
            <span className="text-[10px] font-mono text-slate-400 uppercase tracking-wider block mb-3 flex items-center gap-1.5">
              <ClipboardList className="w-4 h-4 text-indigo-400" />
              My Active Operational Assignments
            </span>

            {assignedIncidents.length > 0 ? (
              <div className="space-y-3">
                {assignedIncidents.map((inc) => (
                  <div 
                    key={inc.id} 
                    className="bg-slate-950 p-3.5 rounded-xl border border-indigo-950 flex flex-col justify-between gap-3 text-xs"
                  >
                    <div className="space-y-1">
                      <span className="bg-rose-500/10 text-rose-400 border border-rose-500/20 px-2 py-0.5 rounded font-mono font-bold text-[9px] uppercase">
                        [{inc.severity} SEVERITY]
                      </span>
                      <h4 className="font-bold text-slate-200 mt-1">{inc.title}</h4>
                      <p className="text-[11px] text-slate-400 leading-relaxed">{inc.description}</p>
                      <div className="text-[10px] text-slate-400 flex items-center gap-1.5 pt-1">
                        <MapPin className="w-3 h-3 text-rose-500" />
                        <span>Location: <strong>{inc.locationName}</strong></span>
                      </div>
                    </div>

                    <button
                      onClick={() => onResolveIncident(inc.id)}
                      className="w-full bg-emerald-600 hover:bg-emerald-500 text-white font-semibold py-2 rounded-lg transition-colors text-xs flex items-center justify-center gap-1.5 mt-1"
                    >
                      <ThumbsUp className="w-3.5 h-3.5" />
                      Mark Task as Resolved
                    </button>
                  </div>
                ))}
              </div>
            ) : (
              <div className="bg-slate-950/60 p-6 rounded-xl border border-slate-800 text-center flex flex-col items-center justify-center min-h-[160px] text-slate-500">
                <UserCheck className="w-8 h-8 text-slate-700 mb-2" />
                <p className="font-semibold text-slate-400 text-xs">No active emergency tasks.</p>
                <p className="text-[10px] text-slate-500 mt-1 max-w-xs">
                  Standby at your station ({myRoster.locationName}) or report local crowd density queues using the panel on the right.
                </p>
              </div>
            )}
          </div>

          <div className="border-t border-slate-800/60 pt-3 mt-4 text-[10px] text-slate-400 italic">
            🚨 Note: All high-severity incidents are synchronized automatically with the Command Center.
          </div>
        </div>

        {/* Report Queue/Crowd status */}
        <form onSubmit={handleUpdateCrowd} className="bg-slate-900/40 border border-slate-800 p-4 rounded-2xl shadow-xl space-y-3">
          <span className="text-[10px] font-mono text-slate-400 uppercase tracking-wider block">
            Update Station Facility Crowd Index (Sensor/Visual Report)
          </span>

          <div className="space-y-3 text-xs">
            {/* Select Facility */}
            <div>
              <label className="text-[10px] text-slate-400 block mb-1">Select Facility to Report</label>
              <select
                value={selectedFacilityId}
                onChange={(e) => setSelectedFacilityId(e.target.value)}
                className="w-full bg-slate-800 border border-slate-700 text-slate-200 text-xs rounded-lg py-2.5 px-3 outline-none focus:border-indigo-600"
                required
              >
                <option value="">Select facility...</option>
                {facilities
                  .filter(f => f.type !== FacilityType.SEAT)
                  .map((f) => (
                    <option key={f.id} value={f.id}>
                      [{f.type}] {f.name} (Now: {f.crowdLevel})
                    </option>
                  ))}
              </select>
            </div>

            <div className="grid grid-cols-2 gap-3">
              {/* Select Crowd Level */}
              <div>
                <label className="text-[10px] text-slate-400 block mb-1">Observed Crowd Level</label>
                <select
                  value={crowdLevel}
                  onChange={(e) => setCrowdLevel(e.target.value)}
                  className="w-full bg-slate-800 border border-slate-700 text-slate-200 text-xs rounded-lg py-2 px-2.5 outline-none"
                >
                  <option value="Low">Low</option>
                  <option value="Medium">Medium</option>
                  <option value="High">High</option>
                  <option value="Critical">Critical</option>
                </select>
              </div>

              {/* Input Wait Time */}
              <div>
                <label className="text-[10px] text-slate-400 block mb-1">Queue Wait Time (mins)</label>
                <input
                  type="number"
                  value={waitTime}
                  onChange={(e) => setWaitTime(Math.max(0, parseInt(e.target.value) || 0))}
                  min="0"
                  max="120"
                  className="w-full bg-slate-800 border border-slate-700 text-slate-200 text-xs rounded-lg py-1.5 px-2.5 outline-none"
                  required
                />
              </div>
            </div>
          </div>

          <button
            type="submit"
            disabled={isUpdating || !selectedFacilityId}
            className="w-full bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold py-2.5 rounded-xl flex items-center justify-center gap-1.5 transition-all shadow-md disabled:opacity-40"
          >
            {isUpdating ? (
              <Loader2 className="w-4 h-4 animate-spin" />
            ) : (
              <RefreshCcw className="w-4 h-4 text-indigo-300" />
            )}
            <span>Update Crowd Load Status</span>
          </button>
        </form>
      </div>
    </div>
  );
}
